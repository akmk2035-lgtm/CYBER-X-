# CYBER X — Android Hacker UI Demo

A native Android project with a neon-green cyber dashboard, demo command console,
device information, and basic local Wi-Fi status.

## Build an APK using GitHub Actions (phone-friendly)
1. Create a GitHub account and a new repository named `CYBER-X`.
2. Upload the contents of this project ZIP to the repository (not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build CYBER X APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `CYBER-X-debug-apk`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone.

## Local build
Requires JDK 17 and Gradle 8.9+:
`gradle assembleDebug`

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Notes
- This is a starter project; it is not yet a penetration-testing tool.
- The terminal accepts only harmless demo commands.
- Network page displays basic information about the phone's own Wi-Fi connection.
- No permission for remote access, packet capture, or other-device scanning is requested.
