package com.cyberx.app

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.content.Context
import android.net.wifi.WifiManager
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 10, 9)
    private val panel = Color.rgb(10, 22, 18)
    private val green = Color.rgb(0, 255, 128)
    private val muted = Color.rgb(112, 160, 135)
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LOW_PROFILE
        showDashboard()
    }

    private fun base(title: String, subtitle: String) {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 24)
            setBackgroundColor(bg)
        }
        scroll.addView(body)
        setContentView(scroll)
        label("CYBER X  //  DIGITAL OPS", 13, green, true)
        label(title, 27, Color.WHITE, true)
        label(subtitle, 12, muted, false)
        space(18)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) {
        body.addView(TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            typeface = if (bold) Typeface.MONOSPACE else Typeface.MONOSPACE
            if (bold) setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        })
    }

    private fun space(h: Int) {
        body.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) })
    }

    private fun card(title: String, detail: String, action: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(15, 12, 15, 12)
            setBackgroundColor(panel)
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(green)
            typeface = Typeface.MONOSPACE
        })
        box.addView(TextView(this).apply {
            text = detail
            textSize = 12f
            setTextColor(Color.LTGRAY)
            typeface = Typeface.MONOSPACE
            setPadding(0, 6, 0, 0)
        })
        if (action != null) box.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 10
        body.addView(box, lp)
    }

    private fun button(text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            setTextColor(green)
            setBackgroundColor(panel)
            typeface = Typeface.MONOSPACE
            isAllCaps = false
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 8
        body.addView(b, lp)
    }

    private fun showDashboard() {
        base("SYSTEM DASHBOARD", "LOCAL DEVICE OVERVIEW  /  SAFE MODE")
        card("● SYSTEM ONLINE", "CYBER X interface initialized successfully")
        card("DEVICE", "${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE}  |  SDK ${Build.VERSION.SDK_INT}")
        card("SECURITY NOTE", "This app shows local device information. It does not access other devices or networks.")
        button("01  /  TERMINAL") { showTerminal() }
        button("02  /  DEVICE INFO") { showDevice() }
        button("03  /  NETWORK INFO") { showNetwork() }
        button("04  /  ABOUT") { showAbout() }
        label("STATUS: READY                                      v1.0", 10, muted, false)
    }

    private fun showTerminal() {
        base("COMMAND CONSOLE", "DEMO COMMANDS  /  LOCAL ONLY")
        val output = TextView(this).apply {
            text = "CYBER X shell [demo]\\nType: help\\n"
            textSize = 13f
            setTextColor(green)
            typeface = Typeface.MONOSPACE
            setPadding(12, 12, 12, 12)
            setBackgroundColor(panel)
        }
        val input = EditText(this).apply {
            hint = "Enter command..."
            setHintTextColor(muted)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            typeface = Typeface.MONOSPACE
        }
        body.addView(output)
        body.addView(input)
        button("EXECUTE") {
            val cmd = input.text.toString().trim().lowercase()
            val result = when (cmd) {
                "help" -> "Available: help, date, device, clear, about"
                "date" -> java.util.Date().toString()
                "device" -> "${Build.MANUFACTURER} ${Build.MODEL} / Android ${Build.VERSION.RELEASE}"
                "about" -> "CYBER X local demo console. No remote access."
                "clear" -> "CLEAR_SCREEN"
                "" -> "Enter a command first."
                else -> "Unknown demo command. Type help."
            }
            if (result == "CLEAR_SCREEN") output.text = "CYBER X shell [demo]\\n"
            else output.append("\\n> $cmd\\n$result\\n")
            input.setText("")
        }
        button("← BACK TO DASHBOARD") { showDashboard() }
    }

    private fun showDevice() {
        base("DEVICE INFORMATION", "INFORMATION PROVIDED BY ANDROID")
        card("MANUFACTURER", Build.MANUFACTURER)
        card("MODEL", Build.MODEL)
        card("ANDROID VERSION", Build.VERSION.RELEASE)
        card("SDK VERSION", Build.VERSION.SDK_INT.toString())
        card("DEVICE", Build.DEVICE)
        button("← BACK") { showDashboard() }
    }

    @Suppress("DEPRECATION")
    private fun showNetwork() {
        base("NETWORK INFORMATION", "BASIC LOCAL CONNECTION STATUS")
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val enabled = wm.isWifiEnabled
        card("WI-FI RADIO", if (enabled) "Enabled" else "Disabled")
        val info = wm.connectionInfo
        val connected = enabled && info.networkId != -1
        card("CONNECTION", if (connected) "Connected to a Wi-Fi network" else "Not connected to Wi-Fi")
        if (connected) {
            card("LOCAL IP", Formatter.formatIpAddress(info.ipAddress))
            card("LINK SPEED", "${info.linkSpeed} Mbps")
        } else {
            card("LOCAL IP", "Unavailable")
        }
        label("No scanning, interception, or external access is performed.", 11, muted, false)
        button("← BACK") { showDashboard() }
    }

    private fun showAbout() {
        base("ABOUT CYBER X", "PERSONAL ANDROID PROJECT")
        card("VERSION", "1.0")
        card("PURPOSE", "A neon-green cyber-themed dashboard with a demo terminal and basic local device/network information.")
        card("PRIVACY", "No account, analytics, tracking, or remote-control features are included.")
        button("← BACK") { showDashboard() }
    }
}
